package com.iflytek.demo;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import java.io.FileOutputStream;

public class LotExcelDate {
    public static void main(String[] args) throws Throwable {
        Workbook wb = new SXSSFWorkbook(100); // 在内存中保留100行，超过的行将刷新到磁盘
        Sheet sh = wb.createSheet();
        for(int rownum = 0; rownum < 100000; rownum++){
            Row row = sh.createRow(rownum);
            for(int cellnum = 0; cellnum < 10; cellnum++){
                //输入内容区域
                Cell cell = row.createCell(cellnum);
                if(rownum == 0){//标题行  第一行
                    // 大写字母
                    String address = new CellReference(cell).formatAsString();
                    cell.setCellValue(address);
                }else{
                    cell.setCellValue("1");
                }
            }
        }
        FileOutputStream out = new FileOutputStream("D:/sxssf.xlsx");
        wb.write(out);
        out.close();
    }
}
